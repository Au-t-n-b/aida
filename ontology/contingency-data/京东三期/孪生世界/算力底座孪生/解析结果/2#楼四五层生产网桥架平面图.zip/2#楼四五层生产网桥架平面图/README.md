# 2#楼四五层生产网桥架平面图.dxf — 解析结果

机房 DXF 施工图解析结果：`room3d.json`（合并版全要素）+ 设备/桥架/结构 分离 JSON + 平面图，供下游构建 3D 机房 / 可视化直接消费。

## 目录结构

| 文件 | 数量 | 用途 |
|---|---|---|
| `README.md` | — | 本文档：坐标系 + 各 JSON 字段说明 |
| `result.json` | — | 纯结构化索引（finalize 产出，顶层载图框坐标系参数） |
| `room3d.json` | — | 合并版全要素（机柜/柱/空调/桥架/通道/挡板/墙/门/机房 + qa） |
| `cabinets.json` | 249 | 设备（机柜/ODF/空调）数组 |
| `trays.json` | 33 | 桥架（多层，逐层 宽/高/标高） |
| `structure.json` | 墙995/柱72/通道12 | 墙壁线段 + 结构柱 + 封闭通道 |
| `summary.json` | — | 汇总（数量/坐标系参数） |
| `plan.svg` | — | 平面图（图例置顶 + 1000 标尺框 + CAD 图框） |
| `review/` + `review_manifest.json` | — | L2 视觉审查图与清单（needs_s3 项；空=无需审查） |
| `_manifest.json` / `parse-report.json` / `debug.json` | — | 管线状态 / 解析报告 / 计时（--debug） |

## 坐标系（所有 JSON 通用）

- **基准**：CAD 最外层图框，DXF 范围见 `result.json.frame_box_dxf`（summary.json 同载），实际尺寸 `frame_wh` = 126150mm × 89100mm。
- **归一化**：以图框**左上角为 (0,0)**，**保持比例**映射进 1000×1000 网格，**Y 轴向下**。
- 因图框宽>高，归一化后内容 X∈[0,1000]、Y∈[0,706.3]（不失真）。
- **比例**：`scale_to_1000` ≈ 0.007927，即 1 个归一化单位 ≈ 126.15mm；反之 mm × 0.007927 = 归一化值。
- 后缀约定：`*_norm` = 1000 归一化坐标；`*_mm` = 相对图框左上角的真实毫米（Y 向下）。

## result.json — 索引 + 坐标系参数

| 键 | 类型 | 含义 |
|---|---|---|
| `file_name` / `file_type` / `output_dir` / `cli_version` | str | 文件与管线元数据 |
| `sections` / `tables` / `analysis` / `figures` | list | 通用证据链索引（CAD 文档当前为空） |
| `frame_box_dxf` | float[4] | 图框在原始 DXF 的范围 [minx,miny,maxx,maxy] |
| `frame_wh` | float[2] | 图框实际尺寸 [宽mm, 高mm] |
| `scale_to_1000` / `grid` / `frame_norm` | — | 归一化参数（与 summary.json 一致） |

## room3d.json — 合并版全要素

顶层：`source` / `frame_box_dxf` / `frame_wh` / `scale_to_1000` / `grid` / 各元素数组 / `build3d` / `qa`。

| 元素数组 | 字段 |
|---|---|
| `cabinets[]` | `id` `code` `room` `floor` `facing`(N/S/E/W) `facing_source` `footprint_norm` `footprint_mm` `size_mm` `power_kw` `dev_type`(计算柜/网络柜/ODF) `confidence` `needs_s3` |
| `columns[]` | `id` `footprint_norm` `footprint_mm` `size_mm` `confidence` `needs_s3` |
| `cooling[]` | `id` `kind`(cdu/humidifier) `footprint_norm` `footprint_mm` `confidence` `needs_s3` |
| `trays[]` | `id` `system`(主/列/竖向) `medium` `scope`(机房内部/走廊/跨楼层垂直) `tray_type` `axis`(H/V/Z) `centerline_norm` `footprint_norm` `footprint_mm` `layers[{elevation_mm,size_mm}]` `confidence` `needs_s3` |
| `aisles[]` | `id` `room` `type`(cold/hot/unknown) `centerline_norm` `footprint_norm` `bounded_by`(door,door) `confidence` `needs_s3` |
| `baffles[]` | `id` `axis`(H/V) `footprint_norm` `footprint_mm` `line_count` `confidence` |
| `walls[]` | `id` `kind`(外墙/隔墙) `p0_norm` `p1_norm` |
| `doors[]` | `id` `kind`(防火门) `footprint_norm` `ctr_norm` `confidence` |
| `rooms[]` | `id` `footprint_norm` `footprint_mm` `cabinet_ids` |
| `build3d` | 下游拉伸参数：`cabinet_height_mm` `column_to_ceiling` `tray_note` `aisle_note` |
| `qa` | `counts` `dev_types` `coded_ratio` `needs_s3_count` `needs_s3` `ir_anomalies` `warnings` `frame_basis`(图框/降级包络) |

## cabinets.json — 设备数组

| 键 | 类型 | 含义 |
|---|---|---|
| `id` / `code` | str | 内部 id / 设备编号（A1–A18/B/C/D；ODF；空调为 CU-n） |
| `type` | str | 计算柜 / 网络柜 / ODF柜 / CDU / 恒湿机 |
| `room` | str/null | 所属机房 |
| `power` | str/null | 功率（如 `54kW`）；非 IT 机柜为 null |
| `facing` | str/null | **机柜朝向** N/S/E/W（门/正面方向）|
| `tl_x`,`tl_y` | float | 左上角（归一化 1000）|
| `ctr_x`,`ctr_y` | float | 中心（归一化 1000）|
| `w_mm`,`h_mm` | int | 真实平面尺寸（宽 × 进深）|
| `footprint_norm`/`_mm` | float[4] | 包围盒 [x0,y0,x1,y1]（归一化 / 毫米）|

> 机柜分类：按功率阈值 30kW 分 计算柜(≥30)/网络柜(<30)。

## trays.json — 桥架（多层）

顶层：`note` / `frame_norm` / `scale_to_1000` / `trays[]`。

`trays[]`：`id` / `system`(主/列/竖向) / `scope`(机房内部/走廊/跨楼层垂直) / `kind`(型式) / `axis`(H/V/Z) / `centerline_norm` / `length_mm` / `n_layers` / `layers[]`。

`layers[]`：`level`(层序) / `width_mm`(槽宽) / `height_mm`(槽高/深) / `base_elev_mm`(底面标高 FL) / `footprint_norm`/`_mm`。

> 桥架物理多层在 2D 几何完全重叠，层数/逐层规格由标注引线判定（非几何）。

## structure.json — 墙壁 / 柱 / 封闭通道

| 键 | 含义 |
|---|---|
| `frame_norm` / `scale_to_1000` | 坐标系 |
| `walls` | 墙体线段 `[[x1,y1,x2,y2]…]`（归一化）|
| `columns` | 结构柱 `[{id, ctr_x, ctr_y, w_mm, h_mm, footprint_norm/_mm}]`（仅 COLUMN 层）|
| `aisles` | 封闭通道 `[{id, room, footprint_norm, centerline_norm, bounded_by}]`（门弧锚定，每机柜行一条）|

## summary.json — 汇总

| 键 | 含义 |
|---|---|
| `source` | 源文件名 |
| `frame_box_dxf` / `frame_wh` | 图框 DXF 范围 / 实际宽高 mm |
| `scale_to_1000` / `grid` / `frame_norm` | 归一化参数（见「坐标系」） |
| `counts` | `devices`(含 `by_type` 分布) / `trays`(含 `by_scope`) / `walls` / `columns` / `aisles` |
| `per_room` | 各机房设备数 |

## 构建 3D 机房

统一换算 `真实mm = 归一化值 / 0.007927`。
- **设备**：以 `tl_x,tl_y` 为左上、`w_mm,h_mm` 为平面尺寸，沿 +Z 拉伸机柜高（IT 常规 2000mm）。
- **桥架**：对每条通道的每一层，以 `footprint` 为底、`base_elev_mm` 为底标高，沿 +Z 拉伸 `height_mm`。
- **墙**：`walls` 线段沿 +Z 拉伸墙高。

## 数量

设备 249（{'ODF柜': 15, '网络柜': 69, '计算柜': 144, '恒湿机': 6, 'CDU': 15}）· 桥架 33（{'走廊': 7, '机房内部': 18, '跨楼层垂直': 2}）· 墙 995 · 柱 72 · 封闭通道 12 · 机房分布 {'F1-R1': 76, 'F1-R2': 76, 'F1-R3': 76}。
